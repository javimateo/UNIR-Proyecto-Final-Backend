import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  title = 'TeleMarket';
  rolActual: string = 'usuario'; 

  cambiarRol(nuevoRol: string) {
    this.rolActual = nuevoRol;
  }
}